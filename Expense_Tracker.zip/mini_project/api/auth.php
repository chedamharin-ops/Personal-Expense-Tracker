<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include 'db_connect.php';
include 'mail_helper.php';

// Auto-migration: ensure is_verified column exists
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'is_verified'");
if ($colCheck->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN is_verified TINYINT(1) DEFAULT 0");
    // Mark all existing users as verified so they aren't locked out
    $conn->query("UPDATE users SET is_verified = 1 WHERE is_verified = 0 OR is_verified IS NULL");
}

// Ensure email_verifications table exists
$conn->query("CREATE TABLE IF NOT EXISTS email_verifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    code VARCHAR(6) NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Get JSON POST data
$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['action'])) {
    if ($data['action'] === 'register') {
        $name = $conn->real_escape_string($data['name']);
        $email = $conn->real_escape_string($data['email']);
        $password = password_hash($data['password'], PASSWORD_DEFAULT);

        // Check if a verified account already exists
        $check = $conn->query("SELECT id, is_verified FROM users WHERE email='$email'");
        if ($check->num_rows > 0) {
            $existing = $check->fetch_assoc();
            if (intval($existing['is_verified']) === 1) {
                echo json_encode(["status" => "error", "message" => "Email already exists"]);
                exit();
            }
            // Unverified account exists — delete it and re-register so a fresh OTP is sent
            $conn->query("DELETE FROM users WHERE email='$email'");
            $conn->query("DELETE FROM email_verifications WHERE email='$email'");
        }

        // Insert as UNVERIFIED — email must be confirmed before they can log in
        $sql = "INSERT INTO users (name, email, password, is_verified) VALUES ('$name', '$email', '$password', 0)";
        if ($conn->query($sql) !== TRUE) {
            echo json_encode(["status" => "error", "message" => "Database error"]);
            exit();
        }

        // Generate 6-digit OTP and store it
        $code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        $conn->query("DELETE FROM email_verifications WHERE email='$email'");
        $conn->query("INSERT INTO email_verifications (email, code, expires_at) VALUES ('$email', '$code', DATE_ADD(NOW(), INTERVAL 15 MINUTE))");

        // Send verification email
        $emailSent = false;
        try {
            sendOtpEmail($email, $code, 'verify');
            $emailSent = true;
        } catch (Exception $e) {}

        $response = [
            "status"  => "verify_email",
            "message" => $emailSent ? "Verification code sent to $email" : "Account created. Check your email for the OTP.",
            "email"   => $email
        ];
        if (!$emailSent) {
            $response["demo_code"] = $code; // Fallback for dev if SMTP fails
        }
        echo json_encode($response);
    } 
    else if ($data['action'] === 'login') {
        $email = $conn->real_escape_string($data['email']);
        $password = $data['password']; // Don't escape password because it will be verified

        $result = $conn->query("SELECT * FROM users WHERE email='$email'");
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Block login for unverified accounts
                if (intval($user['is_verified']) === 0) {
                    echo json_encode(["status" => "unverified", "message" => "Please verify your email before signing in.", "email" => $email]);
                    exit();
                }
                echo json_encode([
                    "status" => "success", 
                    "message" => "Login successful", 
                    "user" => ["id" => $user['id'], "name" => $user['name'], "email" => $user['email']]
                ]);
            } else {
                echo json_encode(["status" => "error", "message" => "Incorrect password"]);
            }
        } else {
             echo json_encode(["status" => "error", "message" => "User not found"]);
        }
    } else if ($data['action'] === 'verifyPassword') {
        $user_id = $conn->real_escape_string($data['user_id']);
        $password = $data['password'];

        $result = $conn->query("SELECT password FROM users WHERE id='$user_id'");
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                echo json_encode(["status" => "success", "message" => "Password valid"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Invalid password"]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "User not found"]);
        }
    } else if ($data['action'] === 'updateProfile') {
        $user_id = $conn->real_escape_string($data['user_id']);
        $name = $conn->real_escape_string($data['name']);
        $email = $conn->real_escape_string($data['email']);
        $new_password = isset($data['new_password']) ? $data['new_password'] : '';

        // Check if new email is used by another ID
        $check = $conn->query("SELECT id FROM users WHERE email='$email' AND id != '$user_id'");
        if ($check->num_rows > 0) {
            echo json_encode(["status" => "error", "message" => "Email is already taken by another account"]);
            exit();
        }

        if (!empty($new_password)) {
            $hash = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET name='$name', email='$email', password='$hash' WHERE id='$user_id'";
        } else {
            $sql = "UPDATE users SET name='$name', email='$email' WHERE id='$user_id'";
        }

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Profile updated successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to update profile"]);
        }
    } else if ($data['action'] === 'verifyEmail') {
        $email = $conn->real_escape_string($data['email']);
        $code  = $conn->real_escape_string($data['code']);

        $result = $conn->query("SELECT * FROM email_verifications WHERE email='$email' AND code='$code' AND expires_at > NOW()");
        if ($result->num_rows === 1) {
            // Mark user as verified
            $conn->query("UPDATE users SET is_verified = 1 WHERE email='$email'");
            // Clean up used code
            $conn->query("DELETE FROM email_verifications WHERE email='$email'");
            echo json_encode(["status" => "success", "message" => "Email verified successfully"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Invalid or expired verification code"]);
        }

    } else if ($data['action'] === 'resendVerification') {
        $email = $conn->real_escape_string($data['email']);

        // Check user exists and is not yet verified
        $result = $conn->query("SELECT id, is_verified FROM users WHERE email='$email'");
        if ($result->num_rows === 0) {
            echo json_encode(["status" => "error", "message" => "No account found with that email"]);
            exit();
        }
        $user = $result->fetch_assoc();
        if (intval($user['is_verified']) === 1) {
            echo json_encode(["status" => "error", "message" => "Email is already verified"]);
            exit();
        }

        $code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
        $conn->query("DELETE FROM email_verifications WHERE email='$email'");
        $conn->query("INSERT INTO email_verifications (email, code, expires_at) VALUES ('$email', '$code', DATE_ADD(NOW(), INTERVAL 15 MINUTE))");

        // Send verification email
        $emailSent = false;
        try {
            sendOtpEmail($email, $code, 'verify');
            $emailSent = true;
        } catch (Exception $e) {}

        $response = [
            "status" => "success",
            "message" => "Verification code resent"
        ];
        if (!$emailSent) {
            $response["demo_code"] = $code;
        }
        echo json_encode($response);

    } else if ($data['action'] === 'sendResetCode') {
        $email = $conn->real_escape_string($data['email']);

        // Ensure password_resets table exists
        $conn->query("CREATE TABLE IF NOT EXISTS password_resets (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            code VARCHAR(6) NOT NULL,
            expires_at DATETIME NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");

        // Check if user exists
        $result = $conn->query("SELECT id FROM users WHERE email='$email'");
        if ($result->num_rows === 0) {
            echo json_encode(["status" => "error", "message" => "No account found with that email address"]);
            exit();
        }

        // Generate 6-digit code
        $code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

        // Delete old codes for this email
        $conn->query("DELETE FROM password_resets WHERE email='$email'");

        // Insert new code (use MySQL's NOW() so timezone matches the verification check)
        $conn->query("INSERT INTO password_resets (email, code, expires_at) VALUES ('$email', '$code', DATE_ADD(NOW(), INTERVAL 15 MINUTE))");

        // Send reset code via email
        $emailSent = false;
        try {
            sendOtpEmail($email, $code, 'reset');
            $emailSent = true;
        } catch (Exception $e) {}

        $response = [
            "status"    => "success",
            "message"   => $emailSent ? "Verification code sent to your email" : "Verification code sent"
        ];
        if (!$emailSent) {
            $response["demo_code"] = $code;  // Fallback: show in UI if email fails
        }
        echo json_encode($response);

    } else if ($data['action'] === 'verifyResetCode') {
        $email = $conn->real_escape_string($data['email']);
        $code  = $conn->real_escape_string($data['code']);

        $result = $conn->query("SELECT * FROM password_resets WHERE email='$email' AND code='$code' AND expires_at > NOW()");
        if ($result->num_rows === 1) {
            echo json_encode(["status" => "success", "message" => "Code verified"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Invalid or expired code"]);
        }

    } else if ($data['action'] === 'resetPassword') {
        $email    = $conn->real_escape_string($data['email']);
        $code     = $conn->real_escape_string($data['code']);
        $new_pass = $data['new_password'];

        // Re-verify the code before resetting
        $result = $conn->query("SELECT * FROM password_resets WHERE email='$email' AND code='$code' AND expires_at > NOW()");
        if ($result->num_rows === 0) {
            echo json_encode(["status" => "error", "message" => "Session expired. Please start again."]);
            exit();
        }

        $hash = password_hash($new_pass, PASSWORD_DEFAULT);
        $conn->query("UPDATE users SET password='$hash' WHERE email='$email'");

        // Clean up used code
        $conn->query("DELETE FROM password_resets WHERE email='$email'");

        echo json_encode(["status" => "success", "message" => "Password reset successfully"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid action"]);
}

$conn->close();
?>
