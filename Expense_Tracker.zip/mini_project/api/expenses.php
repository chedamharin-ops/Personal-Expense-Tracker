<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

include 'db_connect.php';

$data = json_decode(file_get_contents("php://input"), true);
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    if (isset($data['action']) && $data['action'] === 'add') {
        $user_id = $conn->real_escape_string($data['user_id']);
        $title = $conn->real_escape_string($data['title']);
        $amount = (float) $data['amount'];
        $category = $conn->real_escape_string($data['category']);
        $date = $conn->real_escape_string($data['date']);

        // Reject future dates
        $today = date('Y-m-d');
        if ($date > $today) {
            echo json_encode(["status" => "error", "message" => "Expense date cannot be in the future"]);
            $conn->close();
            exit;
        }

        $sql = "INSERT INTO expenses (user_id, title, amount, category, date) VALUES ('$user_id', '$title', '$amount', '$category', '$date')";
        
        if ($conn->query($sql) === TRUE) {
            $exp_id = $conn->insert_id;
            echo json_encode(["status" => "success", "message" => "Expense added", "id" => $exp_id]);
        } else {
            echo json_encode(["status" => "error", "message" => "Failed to add expense"]);
        }
    }
    else if (isset($data['action']) && $data['action'] === 'delete') {
         $id = $conn->real_escape_string($data['id']);
         $user_id = $conn->real_escape_string($data['user_id']); // Ensure user can only delete their own
         
         $sql = "DELETE FROM expenses WHERE id='$id' AND user_id='$user_id'";
         if ($conn->query($sql) === TRUE) {
             echo json_encode(["status" => "success", "message" => "Expense deleted"]);
         } else {
             echo json_encode(["status" => "error", "message" => "Failed to delete expense"]);
         }
    }
} else if ($method === 'GET') {
    // Fetch user's expenses
    if (isset($_GET['user_id'])) {
        $user_id = $conn->real_escape_string($_GET['user_id']);
        $result = $conn->query("SELECT * FROM expenses WHERE user_id='$user_id' ORDER BY date DESC");
        
        $expenses = [];
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                // Ensure amount is float
                $row['amount'] = (float) $row['amount'];
                $expenses[] = $row;
            }
        }
        echo json_encode(["status" => "success", "data" => $expenses]);
    } else {
        echo json_encode(["status" => "error", "message" => "Missing user_id"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid HTTP method"]);
}

$conn->close();
?>
