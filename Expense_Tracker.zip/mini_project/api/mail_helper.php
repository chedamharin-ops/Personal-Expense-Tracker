<?php
/**
 * Mail Helper — sends emails via Gmail SMTP using PHPMailer.
 *
 * SETUP:
 * 1. Go to https://myaccount.google.com/security
 * 2. Enable 2-Step Verification
 * 3. Go to https://myaccount.google.com/apppasswords
 * 4. Generate an App Password for "Mail" → "Windows Computer"
 * 5. Paste the 16-character password into SMTP_PASS below
 */

require_once __DIR__ . '/../vendor/PHPMailer-6.9.3/src/PHPMailer.php';
require_once __DIR__ . '/../vendor/PHPMailer-6.9.3/src/SMTP.php';
require_once __DIR__ . '/../vendor/PHPMailer-6.9.3/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// ─── CONFIGURE THESE ────────────────────────────────────────
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'snmims20@gmail.com');
define('SMTP_PASS', 'jjhgaypbmqojdyxd');
define('SMTP_FROM_NAME', 'Expense Tracker');
// ─────────────────────────────────────────────────────────────

/**
 * Send an OTP email.
 *
 * @param string $toEmail  Recipient email
 * @param string $code     The 6-digit OTP
 * @param string $purpose  'reset' | 'verify' — changes email wording
 * @return bool  true on success, throws Exception on failure
 */
function sendOtpEmail(string $toEmail, string $code, string $purpose = 'reset'): bool
{
    $mail = new PHPMailer(true);

    // Server settings
    $mail->isSMTP();
    $mail->Host       = SMTP_HOST;
    $mail->SMTPAuth   = true;
    $mail->Username   = SMTP_USER;
    $mail->Password   = SMTP_PASS;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = SMTP_PORT;

    // Sender & recipient
    $mail->setFrom(SMTP_USER, SMTP_FROM_NAME);
    $mail->addAddress($toEmail);

    // Determine subject & heading based on purpose
    if ($purpose === 'verify') {
        $subject = 'Verify your Email — Expense Tracker';
        $heading = 'Email Verification';
        $intro   = 'Thank you for signing up! Use the code below to verify your email address.';
    } else {
        $subject = 'Password Reset Code — Expense Tracker';
        $heading = 'Password Reset';
        $intro   = 'We received a request to reset your password. Use the code below to proceed.';
    }

    // Build a nice HTML email
    $htmlBody = <<<HTML
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background:#f0f2f5;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="padding:40px 20px;">
    <tr>
      <td align="center">
        <table width="460" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 4px 24px rgba(0,0,0,0.08);">
          <!-- Header -->
          <tr>
            <td style="background:linear-gradient(135deg,#6366f1,#4f46e5);padding:32px 36px;text-align:center;">
              <div style="width:56px;height:56px;background:rgba(255,255,255,0.2);border-radius:14px;display:inline-flex;align-items:center;justify-content:center;font-size:24px;margin-bottom:12px;">🔐</div>
              <h1 style="color:#ffffff;font-size:22px;margin:0;font-weight:700;">$heading</h1>
            </td>
          </tr>
          <!-- Body -->
          <tr>
            <td style="padding:36px;">
              <p style="color:#475569;font-size:15px;line-height:1.6;margin:0 0 24px;">$intro</p>
              <div style="background:#f8fafc;border:2px dashed #6366f1;border-radius:12px;padding:24px;text-align:center;margin-bottom:24px;">
                <p style="color:#64748b;font-size:13px;margin:0 0 8px;text-transform:uppercase;letter-spacing:0.05em;font-weight:600;">Your verification code</p>
                <p style="color:#1e293b;font-size:36px;font-weight:800;letter-spacing:8px;margin:0;font-family:'Courier New',monospace;">$code</p>
              </div>
              <p style="color:#94a3b8;font-size:13px;line-height:1.5;margin:0;">
                ⏱ This code expires in <strong style="color:#f59e0b;">15 minutes</strong>.<br>
                If you didn't request this, you can safely ignore this email.
              </p>
            </td>
          </tr>
          <!-- Footer -->
          <tr>
            <td style="background:#f8fafc;padding:20px 36px;text-align:center;border-top:1px solid #e2e8f0;">
              <p style="color:#94a3b8;font-size:12px;margin:0;">© 2026 Expense Tracker. All rights reserved.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
HTML;

    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = $htmlBody;
    $mail->AltBody = "Your $heading code is: $code\nThis code expires in 15 minutes.";

    $mail->send();
    return true;
}
?>
