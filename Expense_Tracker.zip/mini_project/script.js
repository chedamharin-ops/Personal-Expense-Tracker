// ===== Auth Guard =====
const session = JSON.parse(localStorage.getItem('et_session') || 'null');
if (!session || !session.loggedIn) {
  window.location.replace('login.html');
}

// ===== Prevent forward-navigation to dashboard after logout =====
// When the browser restores this page from bfcache (back/forward buttons),
// the auth guard script above won't re-execute. This listener catches that case.
// We check on EVERY pageshow (not just bfcache) for maximum safety.
window.addEventListener('pageshow', function(event) {
  const freshSession = JSON.parse(localStorage.getItem('et_session') || 'null');
  if (!freshSession || !freshSession.loggedIn) {
    // Session is gone – redirect to login immediately
    window.location.replace('login.html');
    return;
  }
});

// Set user info in header
if (session) {
  const avatarEl = document.querySelector('.header-avatar');
  if (avatarEl && session.name) {
    avatarEl.textContent = session.name.charAt(0).toUpperCase();
    avatarEl.title = session.name;
  }
}

// ===== Expense Data Store =====
let expenses = [];


// ===== Category Config =====
const CATEGORIES = {
  food:          { label: 'Food',          icon: 'fa-utensils',      color: '#ef4444' },
  transport:     { label: 'Transport',     icon: 'fa-bus',           color: '#3b82f6' },
  entertainment: { label: 'Entertainment', icon: 'fa-film',          color: '#a855f7' },
  utilities:     { label: 'Utilities',     icon: 'fa-bolt',          color: '#f59e0b' },
  health:        { label: 'Health',        icon: 'fa-heart-pulse',   color: '#10b981' },
  education:     { label: 'Education',     icon: 'fa-graduation-cap',color: '#06b6d4' },
  shopping:      { label: 'Shopping',      icon: 'fa-bag-shopping',  color: '#ec4899' },
  other:         { label: 'Other',         icon: 'fa-ellipsis',      color: '#64748b' },
};

// Helper: get category config for a given category string.
// Handles "other-xyz" by returning the 'other' config with a custom label.
function getCategoryConfig(catKey) {
  if (CATEGORIES[catKey]) return CATEGORIES[catKey];
  if (catKey && catKey.startsWith('other')) {
    const subCat = catKey.includes('-') ? catKey.substring(catKey.indexOf('-') + 1) : '';
    const label = subCat
      ? 'other-' + subCat
      : 'other';
    return { ...CATEGORIES.other, label };
  }
  return CATEGORIES.other;
}

// Helper: get the base category key for grouping (e.g. "other-lending" → "other")
function getBaseCategoryKey(catKey) {
  if (CATEGORIES[catKey]) return catKey;
  if (catKey && catKey.startsWith('other')) return 'other';
  return catKey;
}

// ===== DOM References =====
const navItems        = document.querySelectorAll('.nav-item[data-section]');
const sections        = document.querySelectorAll('.section');
const expenseForm     = document.getElementById('expense-form');
const expenseTableBody= document.getElementById('expense-tbody');
const recentExpenseTableBody = document.getElementById('recent-expense-tbody');
const filterCategory  = document.getElementById('filter-category');
const filterDateFrom  = document.getElementById('filter-date-from');
const filterDateTo    = document.getElementById('filter-date-to');
const clearFiltersBtn = document.getElementById('clear-filters');
const sidebar         = document.querySelector('.sidebar');
const sidebarOverlay  = document.querySelector('.sidebar-overlay');
const menuToggle      = document.querySelector('.menu-toggle');

// Summary elements
const totalExpenseEl  = document.getElementById('total-expense');
const totalCountEl    = document.getElementById('total-count');
const thisMonthExpenseEl = document.getElementById('this-month-expense');
const topCategoryEl   = document.getElementById('top-category');

// Chart canvases
const categoryChartCanvas = document.getElementById('category-chart');
const trendChartCanvas    = document.getElementById('trend-chart');

// Report elements
const categorySummaryList = document.getElementById('category-summary-list');
const reportChartCanvas   = document.getElementById('report-chart');

// ===== Navigation =====
// Handled by native anchor links in MPA.

// ===== Mobile Sidebar =====
function openSidebar() {
  sidebar.classList.add('open');
  sidebarOverlay.classList.add('active');
}

function closeSidebar() {
  sidebar.classList.remove('open');
  sidebarOverlay.classList.remove('active');
}

menuToggle.addEventListener('click', openSidebar);
sidebarOverlay.addEventListener('click', closeSidebar);


// ===== Toast Notification =====
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icon = type === 'success' ? 'fa-circle-check' : 'fa-circle-xmark';
  toast.innerHTML = `<i class="fa-solid ${icon}"></i><span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}

// Helper: get today's date in YYYY-MM-DD using LOCAL timezone (not UTC)
function getLocalToday() {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, '0');
  const dd = String(now.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

// ===== Add Expense =====
if (expenseForm) {
  // Show/hide the "Specify Category" text box when Other is selected
  const expCategorySelect = document.getElementById('exp-category');
  const otherCategoryGroup = document.getElementById('other-category-group');
  const otherCategoryInput = document.getElementById('exp-other-category');

  if (expCategorySelect && otherCategoryGroup) {
    expCategorySelect.addEventListener('change', () => {
      if (expCategorySelect.value === 'other') {
        otherCategoryGroup.style.display = '';
        otherCategoryInput.focus();
      } else {
        otherCategoryGroup.style.display = 'none';
        otherCategoryInput.value = '';
      }
    });
  }

  expenseForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const title    = document.getElementById('exp-title').value.trim();
    const amount   = parseFloat(document.getElementById('exp-amount').value);
    let   category = document.getElementById('exp-category').value;
    const date     = document.getElementById('exp-date').value;

    if (!title || !amount || !category || !date) {
      showToast('Please fill all fields', 'error');
      return;
    }

    // If "other" is selected and a custom value is provided, combine them
    if (category === 'other' && otherCategoryInput) {
      const otherVal = otherCategoryInput.value.trim().toLowerCase();
      if (otherVal) {
        category = 'other-' + otherVal;
      }
    }

    // Prevent future dates (compare using local date)
    const today = getLocalToday();
    if (date > today) {
      showToast('Expense date cannot be in the future', 'error');
      return;
    }

    const submitBtn = expenseForm.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Adding...';
    submitBtn.disabled = true;

    try {
      const res = await fetch('api/expenses.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'add', user_id: session.id, title, amount, category, date })
      });
      const result = await res.json();
      
      if(result.status === 'success') {
          const expense = { id: result.id, title, amount, category, date };
          expenses.push(expense);
          
          expenseForm.reset();
          if (otherCategoryGroup) otherCategoryGroup.style.display = 'none';
          document.getElementById('exp-date').value = getLocalToday();
          document.getElementById('exp-date').setAttribute('max', getLocalToday());
          showToast('Expense added successfully!');
          refreshAll();
          window.location.replace('index.html'); // Redirect to dashboard
      } else {
          showToast(result.message || 'Error adding expense', 'error');
      }
    } catch(err) {
        showToast('Server error. Is XAMPP running?', 'error');
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
  });

  // Set default date to today and restrict future dates
  const todayStr = getLocalToday();
  const expDateInput = document.getElementById('exp-date');
  expDateInput.value = todayStr;
  expDateInput.setAttribute('max', todayStr);
}

// ===== Delete Expense =====
async function deleteExpense(id) {
  if(!confirm('Are you sure you want to delete this expense?')) return;
  
  // 1. Optimistic Update: Remove from local array immediately for instant feedback
  // We use String() to ensure IDs match regardless of type (string vs number)
  expenses = expenses.filter(e => String(e.id) !== String(id));
  refreshAll(); 
  
  try {
      const res = await fetch('api/expenses.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'delete', id: id, user_id: session.id })
      });
      const result = await res.json();
      
      if(result.status === 'success') {
          showToast('Expense deleted');
          // 2. Final Sync: Re-fetch from server to be 100% sure we are in sync
          await initApp();
      } else {
          showToast(result.message || 'Error deleting', 'error');
          await initApp(); // Revert back to server state on error
      }
  } catch(err) {
      showToast('Server error while deleting', 'error');
      await initApp(); // Revert back to server state on error
  }
}

// ===== Render Expense Table =====
function renderExpenses() {
  if (!expenseTableBody || !filterCategory) return;
  const catFilter  = filterCategory.value;
  const dateFrom   = filterDateFrom.value;
  const dateTo     = filterDateTo.value;

  let filtered = [...expenses];

  // Apply category filter
  if (catFilter !== 'all') {
    if (catFilter === 'other') {
      // Match all "other" and "other-xxx" categories
      filtered = filtered.filter(e => e.category === 'other' || e.category.startsWith('other-'));
    } else {
      filtered = filtered.filter(e => e.category === catFilter);
    }
  }

  // Apply date-from filter
  if (dateFrom) {
    filtered = filtered.filter(e => e.date >= dateFrom);
  }

  // Apply date-to filter
  if (dateTo) {
    filtered = filtered.filter(e => e.date <= dateTo);
  }

  // Sort by date descending
  filtered.sort((a, b) => new Date(b.date) - new Date(a.date));

  if (filtered.length === 0) {
    expenseTableBody.innerHTML = `
      <tr>
        <td colspan="5">
          <div class="empty-state">
            <i class="fa-solid fa-receipt"></i>
            <p>No expenses match the selected filters</p>
          </div>
        </td>
      </tr>`;
    return;
  }

  expenseTableBody.innerHTML = filtered.map(exp => {
    const cat = getCategoryConfig(exp.category);
    const badgeClass = getBaseCategoryKey(exp.category);
    const formattedDate = new Date(exp.date).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric'
    });
    return `
      <tr>
        <td><strong>${exp.title}</strong></td>
        <td class="amount-cell">₹${exp.amount.toFixed(2)}</td>
        <td>
          <span class="category-badge ${badgeClass}">
            <i class="fa-solid ${cat.icon}"></i> ${cat.label}
          </span>
        </td>
        <td>${formattedDate}</td>
        <td>
          <button class="delete-btn" onclick="deleteExpense(${exp.id})" title="Delete">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </td>
      </tr>`;
  }).join('');
}

// ===== Render Recent Expenses (Dashboard) =====
function renderRecentExpenses() {
  if (!recentExpenseTableBody) return;

  // Sort by date descending and get top 5
  let recent = [...expenses].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5);

  if (recent.length === 0) {
    recentExpenseTableBody.innerHTML = `
      <tr>
        <td colspan="5">
          <div class="empty-state" style="padding: 24px;">
            <p>No recent expenses</p>
          </div>
        </td>
      </tr>`;
    return;
  }

  recentExpenseTableBody.innerHTML = recent.map(exp => {
    const cat = getCategoryConfig(exp.category);
    const badgeClass = getBaseCategoryKey(exp.category);
    const formattedDate = new Date(exp.date).toLocaleDateString('en-US', {
      month: 'short', day: 'numeric', year: 'numeric'
    });
    return `
      <tr>
        <td><strong>${exp.title}</strong></td>
        <td class="amount-cell">₹${exp.amount.toFixed(2)}</td>
        <td>
          <span class="category-badge ${badgeClass}">
            <i class="fa-solid ${cat.icon}"></i> ${cat.label}
          </span>
        </td>
        <td>${formattedDate}</td>
        <td>
          <button class="delete-btn" onclick="deleteExpense(${exp.id})" title="Delete">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </td>
      </tr>`;
  }).join('');
}

if (filterCategory) {
  filterCategory.addEventListener('change', renderExpenses);
  filterDateFrom.addEventListener('change', renderExpenses);
  filterDateTo.addEventListener('change', renderExpenses);
}

if (clearFiltersBtn) {
  clearFiltersBtn.addEventListener('click', () => {
    filterCategory.value = 'all';
    filterDateFrom.value = '';
    filterDateTo.value = '';
    renderExpenses();
  });
}

// ===== Update Summary Cards =====
function updateSummary() {
  if (!totalExpenseEl) return;
  const total = expenses.reduce((sum, e) => sum + e.amount, 0);
  const count = expenses.length;

  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  const thisMonthSpend = expenses.reduce((sum, e) => {
    const expDate = new Date(e.date);
    if (expDate.getMonth() === currentMonth && expDate.getFullYear() === currentYear) {
      return sum + e.amount;
    }
    return sum;
  }, 0);

  // Find top category
  const catTotals = {};
  expenses.forEach(e => {
    const baseKey = getBaseCategoryKey(e.category);
    catTotals[baseKey] = (catTotals[baseKey] || 0) + e.amount;
  });

  let topCat = '-';
  let topAmount = 0;
  for (const [cat, amt] of Object.entries(catTotals)) {
    if (amt > topAmount) {
      topAmount = amt;
      topCat = CATEGORIES[cat]?.label || cat;
    }
  }

  // Animate counting
  animateValue(totalExpenseEl, total);
  totalCountEl.textContent = count;
  animateValue(thisMonthExpenseEl, thisMonthSpend);
  topCategoryEl.textContent = topCat;
}

function animateValue(el, target) {
  const duration = 500;
  const start = parseFloat(el.textContent.replace(/[₹,]/g, '')) || 0;
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // ease out cubic
    const current = start + (target - start) * eased;
    el.textContent = '₹' + current.toFixed(2);
    if (progress < 1) requestAnimationFrame(update);
  }

  requestAnimationFrame(update);
}

// ===== Chart.js Charts =====
let categoryChart, trendChart, reportChart;

function getCategoryData() {
  const catTotals = {};
  expenses.forEach(e => {
    const baseKey = getBaseCategoryKey(e.category);
    catTotals[baseKey] = (catTotals[baseKey] || 0) + e.amount;
  });

  const labels = [];
  const data = [];
  const colors = [];

  for (const [cat, amount] of Object.entries(catTotals)) {
    labels.push(CATEGORIES[cat]?.label || cat);
    data.push(amount);
    colors.push(CATEGORIES[cat]?.color || '#64748b');
  }

  return { labels, data, colors };
}

function getTrendData() {
  // Group expenses by date
  const dateMap = {};
  expenses.forEach(e => {
    dateMap[e.date] = (dateMap[e.date] || 0) + e.amount;
  });

  const sorted = Object.entries(dateMap).sort((a, b) => new Date(a[0]) - new Date(b[0]));
  const labels = sorted.map(([date]) =>
    new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  );
  const data = sorted.map(([, amount]) => amount);

  return { labels, data };
}

function renderCharts() {
  if (!categoryChartCanvas || !trendChartCanvas) return;
  const catData = getCategoryData();
  const trendData = getTrendData();

  // ----- Category Doughnut Chart -----
  if (categoryChart) categoryChart.destroy();
  categoryChart = new Chart(categoryChartCanvas, {
    type: 'doughnut',
    data: {
      labels: catData.labels,
      datasets: [{
        data: catData.data,
        backgroundColor: catData.colors,
        borderWidth: 0,
        hoverOffset: 8,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '65%',
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            padding: 16,
            usePointStyle: true,
            pointStyleWidth: 10,
            font: { size: 12, family: 'Inter', weight: '500' },
          },
        },
        tooltip: {
          backgroundColor: '#1e293b',
          titleFont: { family: 'Inter', size: 13 },
          bodyFont: { family: 'Inter', size: 12 },
          padding: 12,
          cornerRadius: 8,
          callbacks: {
            label: (ctx) => ` ₹${ctx.parsed.toFixed(2)}`,
          },
        },
      },
    },
  });

  // ----- Trend Line Chart -----
  if (trendChart) trendChart.destroy();
  trendChart = new Chart(trendChartCanvas, {
    type: 'line',
    data: {
      labels: trendData.labels,
      datasets: [{
        label: 'Daily Spending',
        data: trendData.data,
        borderColor: '#6366f1',
        backgroundColor: 'rgba(99, 102, 241, 0.08)',
        borderWidth: 2.5,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: '#6366f1',
        pointBorderColor: '#fff',
        pointBorderWidth: 2,
        pointRadius: 5,
        pointHoverRadius: 7,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1e293b',
          titleFont: { family: 'Inter', size: 13 },
          bodyFont: { family: 'Inter', size: 12 },
          padding: 12,
          cornerRadius: 8,
          callbacks: {
            label: (ctx) => ` ₹${ctx.parsed.y.toFixed(2)}`,
          },
        },
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { size: 11, family: 'Inter' }, color: '#94a3b8' },
        },
        y: {
          beginAtZero: true,
          grid: { color: 'rgba(0,0,0,0.04)' },
          ticks: {
            font: { size: 11, family: 'Inter' },
            color: '#94a3b8',
            callback: (v) => '₹' + v,
          },
        },
      },
    },
  });
}

// ===== Reports =====
function renderReports() {
  if (!categorySummaryList || !reportChartCanvas) return;
  const catData = getCategoryData();
  const total = catData.data.reduce((s, v) => s + v, 0);

  // Category summary list
  categorySummaryList.innerHTML = catData.labels.map((label, i) => {
    const pct = total > 0 ? ((catData.data[i] / total) * 100).toFixed(1) : 0;
    return `
      <div class="category-item">
        <span class="category-dot" style="background:${catData.colors[i]}"></span>
        <div class="category-info">
          <span class="cat-name">${label}</span>
          <span class="cat-amount">₹${catData.data[i].toFixed(2)} (${pct}%)</span>
        </div>
        <div class="progress-bar-wrapper">
          <div class="progress-bar-fill" style="width:${pct}%; background:${catData.colors[i]}"></div>
        </div>
      </div>`;
  }).join('');

  // Report bar chart
  if (reportChart) reportChart.destroy();
  reportChart = new Chart(reportChartCanvas, {
    type: 'bar',
    data: {
      labels: catData.labels,
      datasets: [{
        label: 'Amount (₹)',
        data: catData.data,
        backgroundColor: catData.colors.map(c => c + '33'),
        borderColor: catData.colors,
        borderWidth: 2,
        borderRadius: 8,
        borderSkipped: false,
      }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#1e293b',
          titleFont: { family: 'Inter', size: 13 },
          bodyFont: { family: 'Inter', size: 12 },
          padding: 12,
          cornerRadius: 8,
          callbacks: {
            label: (ctx) => ` ₹${ctx.parsed.y.toFixed(2)}`,
          },
        },
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { size: 11, family: 'Inter' }, color: '#94a3b8' },
        },
        y: {
          beginAtZero: true,
          grid: { color: 'rgba(0,0,0,0.04)' },
          ticks: {
            font: { size: 11, family: 'Inter' },
            color: '#94a3b8',
            callback: (v) => '₹' + v,
          },
        },
      },
    },
  });
}

// ===== Refresh Everything =====
function refreshAll() {
  updateSummary();
  renderExpenses();
  renderRecentExpenses();
  renderCharts();
  renderReports();
}

// ===== Initial Render =====
// ===== Initial Render =====
async function initApp() {
    if (!session || !session.loggedIn) return;
    
    try {
        const res = await fetch(`api/expenses.php?user_id=${session.id}&_=${Date.now()}`);
        const result = await res.json();
        
        if(result.status === 'success') {
            expenses = result.data || [];
            refreshAll();
        } else {
             showToast('Error loading expenses', 'error');
        }
    } catch(err) {
        console.error("Failed to load expenses from DB", err);
        showToast('Could not load data from database.', 'error');
    }
}
initApp();

// ===== Logout =====
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('et_session');
    window.location.replace('login.html');
  });
}

// ===== Profile Dropdown =====
const profileAvatar = document.getElementById('profile-avatar');
const profileDropdown = document.getElementById('profile-dropdown');

if (profileAvatar && profileDropdown) {
  profileAvatar.addEventListener('click', (e) => {
    e.stopPropagation();
    profileDropdown.classList.toggle('show');
  });

  document.addEventListener('click', (e) => {
    if (!profileDropdown.contains(e.target) && e.target !== profileAvatar) {
      profileDropdown.classList.remove('show');
    }
  });
}

// ===== Profile Modal =====
const profileModal = document.getElementById('profile-modal');
const profileBtn = document.getElementById('profile-btn');
const closeProfileModal = document.getElementById('close-profile-modal');
const cancelProfileBtn = document.getElementById('cancel-profile-btn');
const profileForm = document.getElementById('profile-form');

const profileNameInput = document.getElementById('profile-name');
const profileEmailInput = document.getElementById('profile-email');
const saveProfileBtn = document.getElementById('save-profile-btn');
const inlineEditBtns = document.querySelectorAll('.inline-edit-btn');

const currentPasswordInput = document.getElementById('profile-current-password');
const newPasswordInput = document.getElementById('profile-new-password');
const confirmPasswordInput = document.getElementById('profile-confirm-password');
const newPasswordGroup = document.getElementById('new-password-group');
const confirmPasswordGroup = document.getElementById('confirm-password-group');
const passwordFeedback = document.getElementById('password-feedback');

if (profileBtn && profileModal) {
  // Reset fields to readonly
  const resetProfileFields = () => {
    profileNameInput.readOnly = true;
    profileEmailInput.readOnly = true;
    
    currentPasswordInput.value = '';
    newPasswordInput.value = '';
    confirmPasswordInput.value = '';
    
    newPasswordInput.disabled = true;
    confirmPasswordInput.disabled = true;
    newPasswordGroup.style.opacity = '0.5';
    confirmPasswordGroup.style.opacity = '0.5';
    passwordFeedback.style.display = 'none';
    
    saveProfileBtn.disabled = true;
  };

  // Inline edit button click handlers
  inlineEditBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const wrapper = btn.closest('.input-action-wrapper');
      const input = wrapper.querySelector('input');
      
      if (input.readOnly) {
        input.readOnly = false;
        input.focus();
        saveProfileBtn.disabled = false;
      }
    });
  });

  // Real-time current password verification
  currentPasswordInput.addEventListener('input', async (e) => {
    const val = e.target.value;
    
    if (val === '') {
      passwordFeedback.style.display = 'none';
      newPasswordInput.disabled = true;
      confirmPasswordInput.disabled = true;
      newPasswordGroup.style.opacity = '0.5';
      confirmPasswordGroup.style.opacity = '0.5';
      return;
    }

    try {
        const res = await fetch('api/auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action: 'verifyPassword', user_id: session.id, password: val })
        });
        const result = await res.json();

        if (result.status === 'success') {
          passwordFeedback.style.display = 'block';
          passwordFeedback.style.color = 'var(--success)';
          passwordFeedback.innerHTML = '<i class="fa-solid fa-circle-check"></i> Password matched';
          
          newPasswordInput.disabled = false;
          confirmPasswordInput.disabled = false;
          newPasswordGroup.style.opacity = '1';
          confirmPasswordGroup.style.opacity = '1';
          saveProfileBtn.disabled = false;
        } else {
          passwordFeedback.style.display = 'block';
          passwordFeedback.style.color = 'var(--danger)';
          passwordFeedback.innerHTML = '<i class="fa-solid fa-circle-xmark"></i> Incorrect current password';
          
          newPasswordInput.disabled = true;
          confirmPasswordInput.disabled = true;
          newPasswordGroup.style.opacity = '0.5';
          confirmPasswordGroup.style.opacity = '0.5';
        }
    } catch(err) {
        console.error(err);
    }
  });

  // Open modal & populate data
  profileBtn.addEventListener('click', () => {
    if (profileDropdown) profileDropdown.classList.remove('show');
    
    // Fill in the current user data
    if (session) {
      profileNameInput.value = session.name || '';
      profileEmailInput.value = session.email || '';
    }
    resetProfileFields();
    
    profileModal.classList.add('active');
    document.body.classList.add('modal-open');
  });
  
  // Close modal functions
  const closeProfile = () => {
    profileModal.classList.remove('active');
    document.body.classList.remove('modal-open');
  };
  closeProfileModal.addEventListener('click', closeProfile);
  cancelProfileBtn.addEventListener('click', closeProfile);
  
  // Close on outside click
  profileModal.addEventListener('click', (e) => {
    if (e.target === profileModal) closeProfile();
  });
  
  // Handle form submission
  profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const newName = profileNameInput.value.trim();
    const newEmail = profileEmailInput.value.trim().toLowerCase();
    
    const currentPwd = currentPasswordInput.value;
    const newPwd = newPasswordInput.value;
    const confirmPwd = confirmPasswordInput.value;
    
    if (!newName || !newEmail) {
      showToast('Name and email are required', 'error');
      return;
    }
    
    if (currentPwd !== '' && !newPasswordInput.disabled) {
       if (newPwd.length < 6) {
          showToast('New password must be at least 6 characters', 'error');
          return;
       }
       if (newPwd !== confirmPwd) {
          showToast('New passwords do not match', 'error');
          return;
       }
    }
    
    try {
        const payload = { action: 'updateProfile', user_id: session.id, name: newName, email: newEmail };
        if (currentPwd !== '' && !newPasswordInput.disabled && newPwd === confirmPwd) {
            payload.new_password = newPwd;
        }

        const res = await fetch('api/auth.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const result = await res.json();
        
        if (result.status === 'success') {
            // Update session params
            session.name = newName;
            session.email = newEmail;
            localStorage.setItem('et_session', JSON.stringify(session));

            // Update UI avatar
            const avatarEl = document.querySelector('.header-avatar');
            if (avatarEl) {
              avatarEl.textContent = session.name.charAt(0).toUpperCase();
              avatarEl.title = session.name;
            }

            showToast('Profile updated successfully');
            closeProfile();
        } else {
            showToast(result.message || 'Error updating profile', 'error');
        }
    } catch(err) {
        showToast('Server error while saving profile', 'error');
    }
  });
}
