<?php
include 'api/db_connect.php';
$res = $conn->query("SELECT * FROM expenses ORDER BY id DESC LIMIT 5");
while ($row = $res->fetch_assoc()) {
    print_r($row);
}
?>
